
public class TriAtleta extends Humano implements Ciclista, Corredor, Nadador {

	public TriAtleta(String nome) {
		super(nome);
	}

	@Override
	public void nadar() {

	}

	@Override
	public void correr() {

	}

	@Override
	public void pedalar() {

	}

}
