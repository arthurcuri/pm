
public interface Ciclista {
	public void pedalar();
}
