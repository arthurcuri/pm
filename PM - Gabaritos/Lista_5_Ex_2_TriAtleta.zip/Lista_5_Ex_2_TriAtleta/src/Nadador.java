
public interface Nadador {
	public void nadar();
}
