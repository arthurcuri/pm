
public interface Corredor {
	public void correr();
}
