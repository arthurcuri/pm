package business;

import java.awt.Graphics;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.stream.Collectors;

public class ListaDeFiguras {
	private Deque<Figura> figuras;

	public ListaDeFiguras(int t) {
		figuras = new ArrayDeque<Figura>();
	}

	public int size() {
		return figuras.size();
	}

	public void insere(Figura f) {
		figuras.add(f);
	}

	public void remove() {
		figuras.removeLast();
	}

	public void desenha(Graphics g) {
		for (Figura f: figuras)
			f.desenha(g);
	}
	
	public double areaTotal() {
		return figuras.stream().mapToDouble(Figura::getArea).sum();
	}
	
	
	public long contQuadradoSuperior() {
		double media = figuras.stream().filter((f) -> f instanceof Circulo)
				.mapToDouble(Figura::getArea).average().getAsDouble();
		return figuras.stream().filter((f) -> f instanceof Quadrado)
				.filter((f) -> f.getArea() > media).count();
	}

	public List<Figura> circulosMaiores(int raio) {
		return figuras.stream()
				.filter((f) -> f instanceof Circulo)
				.filter(c -> c.getLado() > 2*raio).collect(Collectors.toList());
	}


}














