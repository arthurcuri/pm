package app;

import base.Ordenador;
import base.Ordenavel;
import base.Pessoa;

class Aplicacao {


	public static void main(String[] args) {
		Pessoa[] pessoas = new Pessoa[3];
		pessoas[0] = new Pessoa("Ze", "rua 0", "324155");
		pessoas[1] = new Pessoa("Ana", "rua 0", "324155");
		pessoas[2] = new Pessoa("Pedro", "rua 0", "324155");

		for (int i = 0; i < 3; i++) {
			System.out.println("Pessoa: " + pessoas[i]);
		}

		Ordenavel[] crescente = Ordenador.crescente(pessoas);

		System.out.println("\n");

		for (int i = 0; i < 3; i++) {
			System.out.println("Pessoa: " + crescente[i]);
		}

		Ordenavel[] decrescente = Ordenador.decrescente(pessoas);

		System.out.println("\n");

		for (int i = 0; i < 3; i++) {
			System.out.println("Pessoa: " + decrescente[i]);
		}

	}
}
