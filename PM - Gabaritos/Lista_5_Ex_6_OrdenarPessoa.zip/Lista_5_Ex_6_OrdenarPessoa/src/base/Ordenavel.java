package base;

public interface Ordenavel {
	
	public boolean menorQue(Ordenavel o);

}
