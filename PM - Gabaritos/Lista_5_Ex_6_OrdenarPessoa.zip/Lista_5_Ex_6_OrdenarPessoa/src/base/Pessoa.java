package base;

public class Pessoa implements Ordenavel {
	private String nome;
	private String endereco;
	private String telefone;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Pessoa(String nome, String endereco, String telefone) {
		super();
		this.nome = nome;
		this.endereco = endereco;
		this.telefone = telefone;
	}

	@Override
	public boolean menorQue(Ordenavel o) {
		if (o instanceof Pessoa) {
			Pessoa p = (Pessoa) o;
			return (this.getNome().compareTo(p.getNome()) < 0);
		}
		return false;
	}
	@Override
	public String toString() {
		return this.getNome();
	}

	
	
}
