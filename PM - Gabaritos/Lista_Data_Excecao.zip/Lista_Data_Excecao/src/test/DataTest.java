package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import business.Data;
import business.ExcecaoDataInvalida;

class DataTest {

	Data d;

	@BeforeEach
	void setUp() throws Exception {
		d = new Data(1, 2, 2019);
	}

	@Test
	void testAdicionaDiasNoMes() {
		d.adicionaDias(1);
		assertEquals(2, d.getDia(), "Erro alterando o dia dentro do mes");
	}

	@Test
	void testAdicionaEntreMeses() {
		d.adicionaDias(d.diasNoMes());
		assertEquals(1, d.getDia(), "Erro no dia alterando o dia entre meses");
		assertEquals(3, d.getMes(), "Erro no mes alterando o dia entre meses");
	}

	@Test
	void testAdicionaEntreAnos() {
		d.adicionaDias(365);
		assertEquals(1, d.getDia(), "Erro no dia alterando o dia entre anos");
		assertEquals(2, d.getMes(), "Erro no mes alterando o dia entre anos");
		assertEquals(2020, d.getAno(), "Erro no ano alterando o dia entre anos");
	}
	
	@Test
	void testExcecaoDataInvalida() {
		assertThrows(ExcecaoDataInvalida.class, () -> { d.setAno(100); }, "Erro ao lancar ExcecaoDataInvalida no atributo ano" );
		assertThrows(ExcecaoDataInvalida.class, () -> { d.setMes(20); }, "Erro ao lancar ExcecaoDataInvalida no atributo mes" );
		assertThrows(ExcecaoDataInvalida.class, () -> { d.setDia(100); }, "Erro ao lancar ExcecaoDataInvalida no atributo dia" );
		
	}

}









