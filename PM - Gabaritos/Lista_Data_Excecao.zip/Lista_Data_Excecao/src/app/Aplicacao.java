package app;

import business.Data;
import business.ExcecaoDataInvalida;

public class Aplicacao {

	public static void main(String[] args) {

		try {
			int i = 0;
			Data hoje = new Data(10, 3, 2021);

			System.out.println("Dia da semana: " + hoje.diaDaSemana());

			i = i / i;  // ArithmeticException: / by 0
			
			
			if (hoje.getDia() > 15) {
				System.exit(0);
			} else {
				System.out.println("Dias no mes: " + hoje.diasNoMes());
				System.out.println("Data por extenso: " + hoje.porExtenso());
				hoje.proximoDia();
				System.out.println("Amanh�: " + hoje.porExtenso());
			}

		} catch (ExcecaoDataInvalida shulambs) {
			System.out.println(shulambs);
		} catch (Exception e) {
			
		} finally {
			System.out.println("That's all folks!");
		}
		
		
		System.out.println("Main apos o try-catch-finally");
	}

}
