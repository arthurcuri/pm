package business;

import java.time.LocalDate;

public class Data {
	private static final int[] numDias = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	private static final String[] diasDaSemana = { "sabado", "domingo", "segunda-feira", "ter�a-feira", "quarta-feira",
			"quinta-feira", "sexta-feira" };
	private static final String[] nomesDoMes = { "janeiro", "fevereiro", "mar�o", "abril", "maio", "junho", 
			"julho", "agosto", "setembro", "outubro", "novembro", "dezembro" };
	private int dia, mes, ano;

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) throws ExcecaoDataInvalida {
		if (dia > 0 && dia <= this.diasNoMes()) {
			this.dia = dia;
		} else {
			throw new ExcecaoDataInvalida("dia", dia);
		}
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) throws ExcecaoDataInvalida {
		if (mes > 0 && mes <= 12) {
			this.mes = mes;
		} else {
			throw new ExcecaoDataInvalida("mes", mes);
		}
	}


	public int getAno() {
		return ano;
	}

	public void setAno(int ano) throws ExcecaoDataInvalida {
		if (ano > 1900) {
			this.ano = ano;
		} else {
			throw new ExcecaoDataInvalida("ano", ano);
		}
	}

	public Data() {
		LocalDate hoje = LocalDate.now();
		this.ano = hoje.getYear();
		this.mes = hoje.getMonthValue();
		this.dia = hoje.getDayOfMonth();
	}

	public Data(int dia, int mes, int ano) throws ExcecaoDataInvalida {
		this.setAno(ano);
		this.setMes(mes);
		this.setDia(dia);
	}

	public int diasNoMes() {
		return (this.mes == 2 && this.eAnoBisexto()) ? 29 : Data.numDias[this.mes - 1];
	}

	public boolean eAnoBisexto() {
		return ((this.ano % 4 == 0) && (this.ano % 100 != 0)) || (this.ano % 400 == 0);
	}

	public void adicionaDias(int dias) {
		if (dias <= 0) {
			return;
		}

		this.dia += dias;

		while (this.dia > this.diasNoMes()) {
			this.dia -= this.diasNoMes();
			this.mes++;

			if (this.mes > 12) {
				this.ano++;
				this.mes = 1;
			}
		}
	}

	public void proximoDia() {
		this.adicionaDias(1);
	}

	public String diaDaSemana() {
		int k = this.dia + (2 * this.mes) + (3 * (this.mes + 1)) / 5 + this.ano + this.ano / 4 - this.ano / 100
				+ this.ano / 400 + 2;
		return Data.diasDaSemana[k % 7];
	}

	public String porExtenso() {
		return this.dia + " de " + Data.nomesDoMes[this.mes - 1] + " de " + this.ano;
	}

}
