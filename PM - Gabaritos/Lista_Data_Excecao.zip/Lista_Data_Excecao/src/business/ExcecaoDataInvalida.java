package business;

public class ExcecaoDataInvalida extends Exception {

	private static final long serialVersionUID = 1L;

	private String nomeAtr;
	private int valor;

	public String getNomeAtr() {
		return nomeAtr;
	}

	public int getValor() {
		return valor;
	}

	ExcecaoDataInvalida(String nome, int val) {
		super("O atributo " + nome + " n�o pode receber " + val);
		nomeAtr = nome;
		valor = val;
	}

}
