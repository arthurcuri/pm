import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class JSONMap {
	
	public static Object parseValue(String valor) {
		try {
			return Integer.parseInt(valor);
		} catch (NumberFormatException e) {
			
		}
		try {
			return Double.parseDouble(valor);
		} catch (NumberFormatException e) {
			
		}
		return valor;
	}

	public static Map<String, Object> fromJSon(String nomeArquivo) throws Exception {

		BufferedReader arquivo = new BufferedReader(new FileReader(nomeArquivo));

		String nome;
		String valor;

		Map<String, Object> saida = new LinkedHashMap<String, Object>();

		String linha = arquivo.readLine();

		while (linha != null) {
			String[] campo = linha.replace("{", "").replace("}", "").split(":");

			if (campo.length > 1) {
				nome = campo[0].trim().replace("\"", "");
				valor = campo[1].trim().replace("\"", "").replace(",", "");
				saida.put(nome, parseValue(valor));
			}
			linha = arquivo.readLine();
		}

		arquivo.close();
		return saida;
	}

	public static void toJSon(Map<String, Object> json, String nomeArquivo) throws Exception {

		PrintWriter arquivo = new PrintWriter(nomeArquivo);

		Set<Map.Entry<String, Object>> lista = json.entrySet();

		arquivo.println("{");

		Iterator<Map.Entry<String, Object>> it = lista.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Object> e = it.next();

			if (e.getValue() instanceof String) {
				arquivo.print("\t\"" + e.getKey() + "\": \"" + e.getValue() + "\"");
			} else {
				arquivo.print("\t\"" + e.getKey() + "\": " + e.getValue());
			}
			if (it.hasNext())
				arquivo.println(",");
			else
				arquivo.println();
		}
		arquivo.println("}");
		arquivo.close();
	}

	
	public static void main(String[] args) throws Exception {
		
		
		Map<String, Object> resultado = fromJSon("entrada.txt");
	
		toJSon(resultado, "saida.txt");

		System.out.println(resultado);
	}
}
