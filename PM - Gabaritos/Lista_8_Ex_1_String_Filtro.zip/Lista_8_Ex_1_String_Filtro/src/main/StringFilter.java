package main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

public class StringFilter {

	public static List<String> filtrar(List<String> lista, char inicial, int comprimento) {
		
		return lista.stream()
				.filter((s) -> Character.toLowerCase(s.charAt(0)) == Character.toLowerCase(inicial))
				.filter((s) -> s.length() == comprimento)
				.collect(Collectors.toList());
				
	}
	
	
	public static void main(String[] args) {

		List<String> completa = getLista();
		
		System.out.println(completa);
		System.out.println();
		
		List<String> filtrada = filtrar(completa, 's', 8); 		
		
		System.out.println(filtrada);
		
		String resposta = JOptionPane.showInputDialog("Digite o caractere inicial: ");
		char c = (resposta != null) ? resposta.charAt(0) : 's';
		
		resposta = JOptionPane.showInputDialog("Digite o comprimento da palavra: ");
		int i = (resposta != null) ? Integer.parseInt(resposta) : 8;
		
		JOptionPane.showMessageDialog(null, filtrar(completa, c, i));
		
		
	}
	
	private static List<String> getLista() {
		List<String> completa = new ArrayList<String>();
		
		completa.add("Shulambs");		completa.add("Parab�ns");
		completa.add("Selenium");		completa.add("Superior");
		completa.add("Sapo");			completa.add("Adoravel");
		completa.add("Leao");			completa.add("Conversa");
		completa.add("fun��es");		completa.add("Streams");
		completa.add("Decisivo");		completa.add("escolas");
		completa.add("m�todo");			completa.add("retorne");
		completa.add("todas");			completa.add("come�am");
		completa.add("Cipreste");		completa.add("Real");
		completa.add("Leopardo");		completa.add("Estrela");
		completa.add("lambda");			completa.add("Dado");
		completa.add("uma");			completa.add("lista");
		completa.add("Strings");		completa.add("desenvolva");
		completa.add("comprimento");	completa.add("usu�rio");
		completa.add("Trigo");			completa.add("Pesquisa");
		completa.add("significado");	completa.add("ingreme");
		completa.add("Juizado");		completa.add("assento");
		completa.add("Balan�a");		completa.add("Algemas");
		completa.add("Adivinho");		completa.add("Atirado");
		completa.add("Silo");			completa.add("Atletico");
		
		return completa;
	}

}
