package base;
import java.time.LocalDateTime;

public class Data implements Ordenavel {
	private int dia, mes, ano;
    static final int numDias[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    private static int cont = 0;
    private int id;
    private static int numDatas = 0;
    
	public static int getNumDatas() {
		return numDatas;
	}

	public static int getCont() {
		return cont;
	}

	public int getId() {
		return id;
	}

	public int getDia() {
		return dia;
	}

	@Override
	public String toString() {
		return this.dia + "/" + this.mes + "/" + this.ano;
	}

	public void setDia(int dia){
		if (dia >= 1 && dia <= Data.numDias[this.mes-1])
			this.dia = dia;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12)
			this.mes = mes;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		if (ano >= 1900)
			this.ano = ano;
	}

	Data() {
		LocalDateTime hoje = LocalDateTime.now();

		this.dia = hoje.getDayOfMonth();
		this.mes = hoje.getMonthValue();
		this.ano = hoje.getYear();
		this.id = ++Data.cont;
		Data.numDatas++;
	}

	public Data(int dia, int mes, int ano) {
		this.setAno(ano);
		this.setMes(mes);
		this.setDia(dia);
		this.id = ++Data.cont;
		Data.numDatas++;
	}

	boolean anoBissexto() {
		return ((this.ano % 4 == 0 && this.ano % 100 != 0) || this.ano % 400 == 0);
	}

	@Override
	protected void finalize() throws Throwable {
		Data.numDatas--;
	}

	@Override
	public boolean menorQue(Ordenavel o) {
		if (o instanceof Data) {
			Data d = (Data) o;
			int d1 = this.ano * 372 + (this.mes-1)*31 + this.dia;
			int d2 = d.ano * 372 + (d.mes-1)*31 + d.dia;
			return (d1 < d2);
		}
		return false;
	}

}




