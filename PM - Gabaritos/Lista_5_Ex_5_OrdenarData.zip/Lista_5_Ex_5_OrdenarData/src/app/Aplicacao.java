package app;

import base.Data;
import base.Ordenador;
import base.Ordenavel;

class Aplicacao {


	public static void main(String[] args) {
			Data[] datas = new Data[3];
			datas[0] = new Data(12, 1, 2018);
			datas[1] = new Data(10, 8, 2020);
			datas[2] = new Data(20, 10, 2019);

			for (int i = 0; i < 3; i++) {
				System.out.println("Data: " + datas[i]);
			}

			Ordenavel[] cres = Ordenador.crescente(datas);

			System.out.println("\n");

			for (int i = 0; i < 3; i++) {
				System.out.println("Data: " + cres[i]);
			}

			Ordenavel[] decres = Ordenador.decrescente(datas);

			System.out.println("\n");
			for (int i = 0; i < 3; i++) {
				System.out.println("Data: " + decres[i]);
			}

	}
}
