package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import app.Conta;



public class ContaTest {
	Conta c1;
	double saldo;

	
	@BeforeEach
	public void setUp() throws Exception {
		c1 = new Conta();
		saldo = c1.getSaldo();
	}

	@Test
	public void testSacarComSaldo() {
		double valor = saldo;
		c1.sacar(valor);
		assertEquals(saldo - valor, c1.getSaldo(), 0.00001);
	}

	@Test
	public void testSacarSemSaldo() {
		c1.sacar(saldo + 1);
		assertEquals(saldo, c1.getSaldo(), 0.00001);
	}
	
	@Test
	public void testSacarNegativo() {
		c1.sacar(-1);
		assertEquals(saldo, c1.getSaldo(), 0.00001);
	}
	
	@Test
	public void testNumContaUnico() {
		int num1 = c1.getNum();
		assertEquals(num1 + 1, (new Conta()).getNum());
	}
	
}














